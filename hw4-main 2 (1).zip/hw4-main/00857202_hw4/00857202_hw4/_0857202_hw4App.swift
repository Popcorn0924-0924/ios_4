//
//  _0857202_hw4App.swift
//  00857202_hw4
//
//  Created by User16 on 2020/11/18.
//

import SwiftUI

@main
struct _0857202_hw4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
